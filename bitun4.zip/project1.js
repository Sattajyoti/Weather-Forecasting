let input = document.querySelector(".input");
let infoTxt = document.querySelector(".info-txt")

const options = {
  method: 'GET',
  headers: {
    'key': '4296a8449e5849c2900142729230712'
  }
};

const getWeather = (city) => {


  fetch('https://api.weatherapi.com/v1/current.json?q=' + city, options)
    .then((response) => {
      if (!response.ok) {
        throw new Error(`HTTP error! Status: ${response.status}`);
      }
      return response.json(); // Assuming the response is in JSON format
    })
    .then((result) => {

      // console.log(result);
      document.querySelector(".celsius").innerHTML = result.current.temp_c + "&#8451" 
      const kelvinTemperature = result.current.temp_c + 273.15;
      document.querySelector(".kelvin").innerHTML = kelvinTemperature.toFixed(2) + 'K';
      document.querySelector(".fahrenheit").innerHTML = result.current.temp_f + "&#8457";

    })
    .catch((error) => {
      console.error(error);
    });


}

submit.addEventListener("click", function (e) {
  e.preventDefault();
  getWeather(city.value);

});

getWeather("Gunupur");

